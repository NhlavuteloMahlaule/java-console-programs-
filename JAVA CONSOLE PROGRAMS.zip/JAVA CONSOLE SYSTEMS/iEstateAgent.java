package estateagentreport;

// Define the iEstateAgent interface
public interface iEstateAgent {
    String getAgentName();
    double getPropertyPrice();
    double getAgentCommission();
}

// Create an abstract class EstateAgent implementing iEstateAgent
abstract class EstateAgent implements iEstateAgent {
    private String agentName;
    private double propertyPrice;

    public EstateAgent(String agentName, double propertyPrice) {
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
    }

    @Override
    public String getAgentName() {
        return agentName;
    }

    @Override
    public double getPropertyPrice() {
        return propertyPrice;
    }

    @Override
    public double getAgentCommission() {
        return propertyPrice * 0.20; // 20% commission
    }
}

// Create a subclass EstateAgentSales that extends EstateAgent
class EstateAgentSales extends EstateAgent {
    public EstateAgentSales(String agentName, double propertySaleAmount) {
        super(agentName, propertySaleAmount);
    }

    public void printPropertyReport() {
        System.out.println("Estate Agent: " + getAgentName());
        System.out.println("Property Sale Price: R" + getPropertyPrice());
        System.out.println("Agent Commission: R" + getAgentCommission());
    }
}

public class RunApplication {
    public static void main(String[] args) {
        // Instantiate EstateAgentSales with sample values
        EstateAgentSales estateAgent1 = new EstateAgentSales("John Doe", 2500000);
        EstateAgentSales estateAgent2 = new EstateAgentSales("Jane Smith", 1500000);

        // Print property reports for estate agents
        System.out.println("Property Sale Commission Report");
        System.out.println("--------------------------------");
        estateAgent1.printPropertyReport();
        System.out.println();
        estateAgent2.printPropertyReport();
    }
}


