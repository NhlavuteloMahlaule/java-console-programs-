package studentmanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;

class Student {
    public String studentId;
    public int age;
    public String email;
    public String course;

    public Student(String studentId, int age, String email, String course) {
        this.studentId = studentId;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getStudentId() {
        return studentId;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentId + "\nAge: " + age + "\nEmail: " + email + "\nCourse: " + course + "\n";
    }
}

public class StudentManagementSystem {
    private static  ArrayList<Student> students = new ArrayList<>();
    private static  Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            printMenu();
            int choice = getUserChoice();
            switch (choice) {
                case 1:
                    captureStudent();
                    break;
                case 2:
                    searchStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    printStudentReport();
                    break;
                case 5:
                    exitApplication();
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\nStudent Management Menu:");
        System.out.println("1. Capture New Student");
        System.out.println("2. Search for a Student");
        System.out.println("3. Delete Student");
        System.out.println("4. Print Student Report");
        System.out.println("5. Exit Application");
    }

    private static int getUserChoice() {
        System.out.print("Enter your choice: ");
        return scanner.nextInt();
    }

    private static void captureStudent() {
        System.out.print("Enter Student ID: ");
        String studentId = scanner.next();

        System.out.print("Enter Student Age: ");
        int age = scanner.nextInt();
        while (age < 16) {
            System.out.println("Invalid age! Age must be greater than or equal to 16.");
            System.out.print("Enter Student Age: ");
            age = scanner.nextInt();
        }

        System.out.print("Enter Student Email: ");
        String email = scanner.next();

        System.out.print("Enter Student Course: ");
        String course = scanner.next();

        Student student = new Student(studentId, age, email, course);
        students.add(student);
        System.out.println("Student details have been successfully saved.");
    }

    private static void searchStudent() {
        System.out.print("Enter Student ID to search: ");
        String searchId = scanner.next();
        boolean found = false;
        for (Student student : students) {
            if (student.getStudentId().equals(searchId)) {
                System.out.println("Student found:\n" + student);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }

    private static void deleteStudent() {
        System.out.print("Enter Student ID to delete: ");
        String deleteId = scanner.next();
        boolean found = false;
        for (Student student : students) {
            if (student.getStudentId().equals(deleteId)) {
                System.out.print("Are you sure you want to delete this student? (yes/no): ");
                String confirmation = scanner.next().toLowerCase();
                if (confirmation.equals("yes")) {
                    students.remove(student);
                    System.out.println("Student deleted successfully.");
                } else {
                    System.out.println("Student not deleted.");
                }
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }

    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            System.out.println("Student Report:");
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    private static void exitApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}
