package cameratechnologyreport;

public class CameraTechnologyReport {
    public static void main(String[] args) {
        // Defining camera manufacturers and their respective prices for DSLR and Mirrorless cameras
        String[] manufacturers = {"CANON", "SONY", "NIKON"};
        int[][] prices = {
            {10500, 8500},
            {9500, 7200},
            {12000, 8000}
        };

        int greatestDifference = 0;
        String greatestDifferenceManufacturer = "";

        // Displaying the table header
        System.out.println("Camera Manufacturer   | DSLR Price (R) | Mirrorless Price (R) | Price Difference (R)");

        for (int i = 0; i < manufacturers.length; i++) {
            String manufacturer = manufacturers[i];
            int dslrPrice = prices[i][0];
            int mirrorlessPrice = prices[i][1];
            int difference = dslrPrice - mirrorlessPrice;

            // Checking if the difference is greater than or equal to R2,500
            String stars = (difference >= 2500) ? "***" : "";

            System.out.printf("%-20s | %-14d | %-19d | %-20d %s%n", manufacturer, dslrPrice, mirrorlessPrice, difference, stars);

            // Updating the greatest difference
            if (difference > greatestDifference) {
                greatestDifference = difference;
                greatestDifferenceManufacturer = manufacturer;
            }
        }

        // Displaying the manufacturer with the greatest cost difference
        System.out.println("\nManufacturer with the greatest cost difference: " + greatestDifferenceManufacturer);
    }
}
