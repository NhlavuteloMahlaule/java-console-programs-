import java.util.Scanner;

class Book {
    public String title;
    public String author;
    public int year;

    public Book(String title, String author, int year) {
        this.title = title;
        this.author = author;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYear() {
        return year;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", Year: " + year;
    }
}

class Library {
    public Book[] books;
    private int numOfBooks;

    public Library(int capacity) {
        books = new Book[capacity];
        numOfBooks = 0;
    }

    public void addBook(String title, String author, int year) {
        if (numOfBooks < books.length) {
            books[numOfBooks] = new Book(title, author, year);
            numOfBooks++;
            System.out.println("Book added successfully!");
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }

    public void searchBook(String title) {
        boolean found = false;
        for (int i = 0; i < numOfBooks; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                System.out.println("Book found:");
                System.out.println(books[i]);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Book not found in the library.");
        }
    }

    public void displayAllBooks() {
        System.out.println("Library Books:");
        for (int i = 0; i < numOfBooks; i++) {
            System.out.println(books[i]);
        }
    }
}

public class LibraryManagementSystem {
    private static final String[] MENU_OPTIONS = {
        "1. Add a book",
        "2. Search for a book",
        "3. Display all books",
        "4. Exit"
    };

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the capacity of the library: ");
        int capacity = scanner.nextInt();
        Library library = new Library(capacity);

        while (true) {
            System.out.println("\nLibrary Management System Menu:");
            for (String option : MENU_OPTIONS) {
                System.out.println(option);
            }
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    scanner.nextLine(); // Consume the newline
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author name: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter publication year: ");
                    int year = scanner.nextInt();
                    library.addBook(title, author, year);
                    break;
                case 2:
                    scanner.nextLine(); // Consume the newline
                    System.out.print("Enter book title to search: ");
                    title = scanner.nextLine();
                    library.searchBook(title);
                    break;
                case 3:
                    library.displayAllBooks();
                    break;
                case 4:
                    System.out.println("Exiting Library Management System. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}


    

